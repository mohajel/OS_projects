// In the Name of God

#if !defined(__DIMOND__)
#define __DIMOND__

#include "defs.h"
#include "bmp24.h"
#include "thread.h"

void apply_dimond_one_line(int i);
void apply_dimond_partly(int start_row, int end_row);
void apply_dimond();

#endif // __DIMOND__